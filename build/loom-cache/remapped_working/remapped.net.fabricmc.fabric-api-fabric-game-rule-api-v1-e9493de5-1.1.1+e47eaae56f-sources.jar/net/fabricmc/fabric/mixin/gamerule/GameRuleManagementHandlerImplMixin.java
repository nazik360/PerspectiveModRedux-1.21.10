/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.gamerule;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Cancellable;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.api.gamerule.v1.rule.DoubleRule;
import net.fabricmc.fabric.api.gamerule.v1.rule.EnumRule;
import net.fabricmc.fabric.impl.gamerule.rpc.FabricGameRuleType;
import net.fabricmc.fabric.impl.gamerule.rpc.FabricTypedRule;
import net.minecraft.server.dedicated.DedicatedServer;
import net.minecraft.server.jsonrpc.JsonRpcLogger;
import net.minecraft.server.jsonrpc.internalapi.MinecraftGameRuleServiceImpl;
import net.minecraft.server.jsonrpc.methods.ClientInfo;
import net.minecraft.server.jsonrpc.methods.GameRulesService;
import net.minecraft.server.jsonrpc.methods.InvalidParameterJsonRpcException;
import net.minecraft.world.level.GameRules;

@Mixin(MinecraftGameRuleServiceImpl.class)
public abstract class GameRuleManagementHandlerImplMixin {
	@Shadow
	@Final
	private DedicatedServer server;

	@Shadow
	public abstract GameRulesService.TypedRule toTypedRule(String name, GameRules.Value<?> gameRule);

	@Shadow
	@Final
	private JsonRpcLogger logger;

	@WrapOperation(method = "updateRule", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/GameRules$Rule;serialize()Ljava/lang/String;"))
	private String updateRule(GameRules.Value<?> rule, Operation<String> original, @Cancellable CallbackInfoReturnable<GameRulesService.TypedRule> cir,
								@Local(argsOnly = true) GameRulesService.UntypedRule untypedRule, @Local(argsOnly = true) ClientInfo remote) {
		final String from = original.call(rule);

		try {
			if (rule instanceof DoubleRule doubleRule) {
				doubleRule.set(Double.parseDouble(untypedRule.value()), server);
				cir.setReturnValue(doUpdate(untypedRule, remote, rule, from));
			} else if (rule instanceof EnumRule<?> enumRule) {
				enumRule.set(untypedRule.value(), server);
				cir.setReturnValue(doUpdate(untypedRule, remote, rule, from));
			}
		} catch (IllegalArgumentException e) {
			throw new InvalidParameterJsonRpcException(e.getMessage());
		}

		return from;
	}

	@Inject(method = "toTypedRule", at = @At("HEAD"), cancellable = true)
	public void toTypedRule(String name, GameRules.Value<?> rule, CallbackInfoReturnable<GameRulesService.TypedRule> cir) {
		if (rule instanceof DoubleRule) {
			cir.setReturnValue(FabricTypedRule.create(name, rule.serialize(), FabricGameRuleType.DOUBLE));
		} else if (rule instanceof EnumRule<?>) {
			cir.setReturnValue(FabricTypedRule.create(name, rule.serialize(), FabricGameRuleType.ENUM));
		}
	}

	@Unique
	private GameRulesService.TypedRule doUpdate(GameRulesService.UntypedRule untypedRule, ClientInfo remote, GameRules.Value<?> rule, String from) {
		// 3 lines copied from vanilla:
		GameRulesService.TypedRule typedRule = this.toTypedRule(untypedRule.key(), rule);
		this.logger.log(remote, "Game rule '{}' updated from '{}' to '{}'", typedRule.key(), from, typedRule.value());
		this.server.onGameRuleChanged(untypedRule.key(), rule);
		return typedRule;
	}
}
